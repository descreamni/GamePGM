#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <conio.h>
#include <windows.h>
#include <string.h>
#include <math.h>
#include "music.h"


#define INITIALIZESIZE 1000000
#define MAXIMUM_READ_LINE 300


enum SortingStyle
{
	LEFT_TO_RIGHT,
	RIGHT_TO_LEFT
};
enum ArraySize
{
	WIDTH = 4,
	HEIGHT = 5
};
enum WatchGap
{
	HOUR_GAP = 1,
	MIN_GAP = 24,
	SECOND_GAP = 18,
	TRACKING = 5,
	Direction_X = 0,
	Direction_Y = 3
};
/*
* DEFAULT PARAMETER OF DIRECTION = (0, 3)
*/
enum Offset
{
	TIMES_OF_CURSOR_RECURSIVE = 6
	
};
void textColor(int colorNum)
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), colorNum);
}
long time_to_number(void);
int number_check(int target);
int number_check(int, int);
void digit_print(int dim[ArraySize::HEIGHT][ArraySize::WIDTH], int gapX, int gapY);
void gotoxy(int x, int y);
void dot_print(int, int iGapX, int iGapY, bool bIsFixedComma);
void Clock(char*);
void StopWatch();
void Render(long _lTime, SortingStyle style);
char* Alarm(char* alarm);
bool Timer(clock_t _startTimer);
bool Menu();
char* Read(char[]);
bool Bell();
void Config();
void ClockBackgroundSize(int startPointX, int startPointY,int x, int y);
//
FILE* direction;

int zero[ArraySize::HEIGHT][ArraySize::WIDTH] =
{
	{1,1,1,1},
	{1,0,0,1},
	{1,0,0,1},
	{1,0,0,1},
	{1,1,1,1}
};


int one[ArraySize::HEIGHT][ArraySize::WIDTH] =
{
	{0,0,1,0},
	{0,0,1,0},
	{0,0,1,0},
	{0,0,1,0},
	{0,0,1,0}
};

int two[ArraySize::HEIGHT][ArraySize::WIDTH] =
{
	{1,1,1,1},
	{0,0,0,1},
	{1,1,1,1},
	{1,0,0,0},
	{1,1,1,1}
};

int three[ArraySize::HEIGHT][ArraySize::WIDTH] =
{
	{1,1,1,1},
	{0,0,0,1},
	{1,1,1,1},
	{0,0,0,1},
	{1,1,1,1}
};

int four[ArraySize::HEIGHT][ArraySize::WIDTH] =
{
	{1,0,0,1},
	{1,0,0,1},
	{1,1,1,1},
	{0,0,0,1},
	{0,0,0,1}
};

int five[ArraySize::HEIGHT][ArraySize::WIDTH] =
{
	{1,1,1,1},
	{1,0,0,0},
	{1,1,1,1},
	{0,0,0,1},
	{1,1,1,1}
};

int six[ArraySize::HEIGHT][ArraySize::WIDTH] =
{
	{1,0,0,0},
	{1,0,0,0},
	{1,1,1,1},
	{1,0,0,1},
	{1,1,1,1}
};

int seven[ArraySize::HEIGHT][ArraySize::WIDTH] =
{
	{1,1,1,1},
	{0,0,0,1},
	{0,0,0,1},
	{0,0,0,1},
	{0,0,0,1}
};

int eight[ArraySize::HEIGHT][ArraySize::WIDTH] =
{
	{1,1,1,1},
	{1,0,0,1},
	{1,1,1,1},
	{1,0,0,1},
	{1,1,1,1}
};

int nine[ArraySize::HEIGHT][ArraySize::WIDTH] =
{
	{1,1,1,1},
	{1,0,0,1},
	{1,1,1,1},
	{0,0,0,1},
	{0,0,0,1}
};
char AlarmTime[6];
int g_iClockDirectionX = WatchGap::Direction_X;
int g_iClockDirectionY = WatchGap::Direction_Y;
char* g_chEmptyColumn = (char*)" ";
char* g_chFillColumn = (char*)"��";
int g_iColorSize = 15;
int g_iBackgroundSize = 1;

int main(void)
{

	char AlarmFileName[40] = "Sheet_Music.muse";
	bool exit = false;
	Read(AlarmFileName);
	while (!exit)
	{
		exit = Menu();
	}
	return 0;
}
bool Menu()
{
	system("cls");
	CHAR input[12];
	printf("-------Watch_Program-------\
\nPlease type the following command\n\
____________________________________\n\n\
Clock		:: Print the Clocks\n\
StopWatch	:: Use the stopWatch\n\
Alarm		:: Set the Alarm Option\n\
Config		:: Set timer options\n\
EXIT		:: Exit the program\n\
====================================\
\n::\
");

	scanf("%s", &input);
	if (stricmp(input, "Clock") == 0)
	{
		Clock(AlarmTime);
	}
	else if (stricmp(input, "StopWatch") == 0)
	{
		StopWatch();
	}
	else if (stricmp(input, "Alarm") == 0)
	{

		strcpy(AlarmTime,Alarm(AlarmTime));
	}
	else if (stricmp(input, "Config") == 0)
	{
		Config();
	}
	else if (stricmp(input, "EXIT") == 0)
	{
		free(AlarmTime);
		return true;
	}


	return false;
}
char* Read(char _direction[])
{
	FILE* Alarm;
	char chr1[MAXIMUM_READ_LINE];
	Alarm = fopen(_direction, "r");
	while (!feof(Alarm))
	{
		fgets(chr1, MAXIMUM_READ_LINE,Alarm);
	}
	printf("%s", chr1);
	return nullptr;
}
bool Bell()
{
	system("cls");

	printf("Press any key");
	music00();
	if (kbhit())
		return true;
	return false;
}

void Config()
{
	char columnE = NULL;
	char columnN = NULL;
	int i = 0;

	while (i != 5)
	{
		system("cls");
		printf("---------Config-------\n\
1. Change the Color\n\
2. Exit\n\
=======================\n\
::");
		scanf("%d", &i);
		switch (i)
		{
		case 1:
		{
			int i = 0;
			while (true)
			{
				system("cls");
				printf("-------Color changer-------\n");
				printf("0	:: BLACK		|  1	:: DARK BLUE\n");
				printf("2	:: DARK GREEN	|  3	:: DARK SKY BLUE\n");
				printf("4	:: DARK RED		|  5	:: DARK PURPLE\n");
				printf("6	:: DARK YELLOW	|  7	:: GREY\n");
				printf("8	:: DARK GREY	|  9	:: BLUE\n");
				printf("10  :: GREEN		|  11	:: SKY BLUE\n");
				printf("12  :: RED			|  13	:: PURPLE\n");
				printf("14  :: YELLOW		|  15	:: WHITE\n");
				printf("Current color :: %d\n", g_iColorSize);
				printf("===========================\n::");
				scanf("%d", &i);
				if (i < 0 || i > 15)
				{
					printf("Please rewrite the code");
					system("pause");
					continue;
				}
				g_iColorSize = i;
				system("cls");
				break;
			}

		}
			break;
		case 2:
		{
			return;
		}
			break;
		}
	}
	system("pause");
}
void ClockBackgroundSize(int startPointX, int startPointY, int x, int y)
{
	gotoxy(startPointX, startPointY);
	for (int i = 0; i < y; i++)
	{
		printf("\n");
		for (int j = 0; j < x; j++)
			printf(" ");
	}
	textColor(g_iColorSize);
}
void StopWatch()
{
	char commend;
	bool bIsEnd = false;
	while (!bIsEnd)
	{
		system("cls");
		printf("Press ENTER to Start");
		commend = getch();
		if (commend == 13)
		{
			system("cls");
			clock_t startTime = clock();
			bIsEnd = Timer(startTime);

		}
	}

}

bool Timer(clock_t _startPoint)
{
	clock_t ResetPoint = _startPoint;
	int min = 0, sec = 0, centiSec;
	char chRetry;
	while (!kbhit())
	{
		clock_t curTime = clock() - ResetPoint;
		centiSec = curTime / 10 - curTime / 1000;
		if (centiSec > 99)
		{
			centiSec = 0;
			ResetPoint = clock();
			sec++;
			//system("cls");
		}
		if (sec >= 60)
		{
			sec = 0;
			min++;
		}
		if (min >= 60)
		{
			min = 0;
		}
		long TimeInt = min * 10000 + sec * 100 + centiSec;
		Render(TimeInt, SortingStyle::RIGHT_TO_LEFT);
		gotoxy(1, 8);
		printf("\nSelect random key to stop\n");
	}

	system("pause");
	system("cls");
	while (true)
	{
	
		printf("      Retry?\n   Select Y or N\n::");
		scanf("%c", &chRetry);
		if (chRetry == 'Y' || chRetry == 'y')
			return false;
		else if (chRetry == 'N' || chRetry == 'n')
			return true;
		else
		{
			system("cls");
			
		}
	}

}
void Clock(char* AlarmTime)
{
	system("cls");

	bool getout = false;
	ClockBackgroundSize(1, 1, 50, 8);
	while (!kbhit())
	{
		gotoxy(1, 3);
		//printf("%s :: %d", AlarmTime, time_to_number());
		if (AlarmTime != NULL && atoi(AlarmTime) == time_to_number())
		{
			while (!getout)
			{
				getout = Bell();
			}
				
		}
		Render(time_to_number(), SortingStyle::LEFT_TO_RIGHT);

		printf("\n\n\n\n?��무키?�� ?��르면 종료?��?��?��.\n");
		//system("cls");
	}
}
void Render(long _lTime, SortingStyle style)
{
	bool bIsFixed = false;
	switch (style)
	{
	case SortingStyle::LEFT_TO_RIGHT:
	{
		number_check(_lTime, Offset::TIMES_OF_CURSOR_RECURSIVE);
		printf("\n");
		bIsFixed = false;
	}
	break;
	case SortingStyle::RIGHT_TO_LEFT:
	{
		number_check(_lTime);
		bIsFixed = true;
	}
	break;
	}
	dot_print(_lTime, Direction_X, Direction_Y, bIsFixed);
}

char* Alarm(char* alarmTime)
{
	/*
	Node* Front = NULL;
	Node* Rear = NULL;
	Terminal temp;

	temp = DownloadNote("Sheet_Music.muse", Front,Rear);
	Front = temp.enter;
	Rear = temp.exit;

	if (Front == NULL && Rear == NULL)
	{
		printf("?��보�?? ?��?�� ?�� ?��?��");
		return;
	}
	while (Front != NULL)
	{
		printf("%s", Front->string);
		Front = DeQueue(Front);
	}
	Rear = NULL;
	system("pause");
	*/
	//system("cls");
	char* alarmtime = (char*)malloc(sizeof(char)*10);
	char temp[7];
	
	time_t current;

	struct tm* d;
	current = time(NULL);
	d = localtime(&current);
	printf("When do you want to?\n");
	printf("%d : %d : %d\n", d->tm_hour, d->tm_min, d->tm_sec);
	scanf("%s", alarmtime);
	if (strlen(alarmtime) != 6)
	{
		printf("?��못된 값입?��?��. ?��?��?�� 맞게 ?��주세?��(?�� :: 010000)");
		system("pause");
		return alarmTime;
	}
	strcpy(temp, alarmtime);
	free(alarmtime);
	if (atoi(temp) == 0)
	{
		printf("?��못된 값입?��?��.");
		system("pause");
		return alarmTime;
	}
	else if (temp == "Reset")
	{
		printf("값이 초기?��?��?��?��.");
		system("pause");
		return NULL;
	}
	alarmtime = temp;
	system("pause");
	return alarmtime;

	/*
	LPSTR words = (LPSTR)malloc(sizeof(LPSTR) * MAX_WORD_SIZE);
	int wordCount = 0;
	DownloadNote("Sheet_Music.muse", words,&wordCount);
	//ReadNote(wordPointer, wordCount);
	system("pause");
	*/
}
long time_to_number(void)
{
	time_t current;
	struct tm* d;
	int hour, min, sec;
	current = time(NULL);
	d = localtime(&current);
	hour = d->tm_hour * 10000;
	min = d->tm_min * 100;
	sec = d->tm_sec;
	return hour + min + sec;
}

/*
*  The parameter k is usually used for the integer of the time (hour, min, sec)
* I parameter is usually used for the width parameter of the array
*/
int number_check(int target)
{
	int startPoint = 1;
	long readSort = (target/100000);
	for (int i = 5; i >= 0; i--)
	{
		readSort = target / (long)pow(10, i);
		if (i == 5)
			startPoint += HOUR_GAP;
		else if (i == 3)
			startPoint += MIN_GAP;
		else if (i == 1)
			startPoint += SECOND_GAP;
		else
			startPoint += TRACKING;
		switch (readSort % 10)
		{
		case 0:
		{
			digit_print(zero, Direction_X + startPoint, Direction_Y);//Direction y is 3
		}
		break;
		case 1:
		{
			digit_print(one, Direction_X + startPoint, Direction_Y);
		}
		break;
		case 2:
		{
			digit_print(two, Direction_X + startPoint, Direction_Y);
		}
		break;
		case 3:
		{
			digit_print(three, Direction_X + startPoint, Direction_Y);
		}
		break;
		case 4:
		{
			digit_print(four, Direction_X + startPoint, Direction_Y);
		}
		break;
		case 5:
		{
			digit_print(five, Direction_X + startPoint, Direction_Y);
		}
		break;
		case 6:
		{
			digit_print(six, Direction_X + startPoint, Direction_Y);
		}
		break;
		case 7:
		{
			digit_print(seven, Direction_X + startPoint, Direction_Y);
		}
		break;
		case 8:
		{
			digit_print(eight, Direction_X + startPoint, Direction_Y);
		}
		break;
		case 9:
		{
			digit_print(nine, Direction_X + startPoint, Direction_Y);
		}
		break;
		}

	}
	return 1;
}
int number_check(int k, int offset)
{
	int startPoint = 1;
	if (k >= 1)
	{
		startPoint = number_check(k / 10, offset-1);
		//
		int as;
		switch (k % 10)
		{
		case 0:
		{
			digit_print(zero, Direction_X+startPoint, Direction_Y);
		}
			break;
		case 1:
		{
			digit_print(one, Direction_X+startPoint, Direction_Y);
		}
			break;
		case 2:
		{
			digit_print(two, Direction_X+startPoint, Direction_Y);
		}
			break;
		case 3:
		{
			digit_print(three, Direction_X+startPoint, Direction_Y);
		}
			break;
		case 4:
		{
			digit_print(four, Direction_X+startPoint, Direction_Y);
		}
			break;
		case 5:
		{
			digit_print(five, Direction_X+startPoint, Direction_Y);
		}
			break;
		case 6:
		{
			digit_print(six, Direction_X+startPoint, Direction_Y);
		}
			break;
		case 7:
		{
			digit_print(seven, Direction_X+startPoint, Direction_Y);
		}
			break;
		case 8:
		{
			digit_print(eight,Direction_X+ startPoint, Direction_Y);
		}
			break;
		case 9:
		{
			digit_print(nine, Direction_X + startPoint, Direction_Y);
		}
			break;
		}
	}
	if (offset == Offset::TIMES_OF_CURSOR_RECURSIVE-2)
		return startPoint + WatchGap::SECOND_GAP;
	else if (offset == Offset::TIMES_OF_CURSOR_RECURSIVE-4)
		return startPoint + WatchGap::MIN_GAP;
	else if (offset == Offset::TIMES_OF_CURSOR_RECURSIVE-6)
		return startPoint + WatchGap::HOUR_GAP;
	else
	{
		return startPoint + WatchGap::TRACKING;
	}
}
void digit_print(int dim[ArraySize::HEIGHT][ArraySize::WIDTH], int gapX, int gapY)
{
	//[?��?�� 5.4.8]?�� ?��?���?�? 참고
	for (int j = 0; j < ArraySize::HEIGHT; j++)
	{
		for (int i = 0; i < ArraySize::WIDTH; i++)
		{
			gotoxy(gapX + i, gapY + j);
			if (dim[j][i] == 1)
			{
				printf("%s",(char*)g_chFillColumn);
				textColor(g_iColorSize);
			}
			else
			{
				printf("%s",(char*)g_chEmptyColumn);
				textColor(g_iColorSize);
			}
		};
		//printf("\n");
	}

	printf("  ");
	
}
//void PaintingType(int ColorPreset, int );
void dot_print(int hour, int iGapX, int iGapY, bool bIsFixedComma)
{
	int i;
	if (hour < 100000 && !bIsFixedComma)
	{
		for (i = 0; i < 2; i++)
		{
			gotoxy(iGapX + 10 + (i * 27), iGapY + 1);
			printf("%s", (char*)g_chFillColumn);
			gotoxy(iGapX + 10 + (i * 27), iGapY + 3);
			printf("%s", (char*)g_chFillColumn);

			textColor(g_iColorSize);
		}
	}
	else
	{
		for (i = 0; i < 2; i++)
		{
			gotoxy(iGapX + 24 + (i * 26), iGapY+ 1);
			printf("%s",(char*)g_chFillColumn);
			gotoxy(iGapX + 24 + (i * 26), iGapY+3);
			printf("%s",(char*)g_chFillColumn);
			textColor(g_iColorSize);
		}
	}

}

void gotoxy(int x, int y)
{
	COORD Pos = { x - 1, y - 1 };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
}


/*
* O(width) * width
*/
